# Cap 2

![Snap Five Flat Visor 5 Panel Cap](images/cap3.png "Snap Back Cap")

## Snap Five Flat Visor 5 Panel Cap


- Baseball Cap
- Unisex
- Twill
- 100% Polyester
- Five Panels
- 85 Degree Crown Angle
- High Shape Structured Profile
- Flat Visor
- PVC Snap Closure
- Tear Out, 2 Part Label
- One Size
- 400gsm

<button onclick="add2cart(event)" 
data-id="p2"
data-title="cap2" 
data-price="40" 
data-col="black"
data-src="cap3.png">add</button>
