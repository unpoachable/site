# Hoodie

![Fleece Pullover Hooded Sweatshirt](images/red-hoodie.png "hoodie")

## Hooded pullover jumper 

- Fleece Pullover Hooded Sweatshirt
- Unisex Regular Fit
- Three End Combed Ringspun Fleece, Brushed Back
- A Premium Hooded Sweat
- Super Soft Hand Feel
- Herringbone Neck Tape For Superior Comfort & Stability
- Flat, Chunky Drawcords With Buttonhole Eyelets
- Double Layer Hood With Cover Seam Drawcord Channel 
- Slimmer Shoulders
- Headphones Access
- Kangaroo Pockets
- XS to 3XL
- 80% Cotton, 20% Polyester
- 280gsm
 
<button onclick="add2cart(event)" 
data-id="p3"
data-title="hoodie" 
data-price="80" 
data-col="black"
data-src="red-hoodie.png">add</button>
