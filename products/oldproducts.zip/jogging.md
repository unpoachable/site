# Jogging bottoms 

![Fleece Jogging Trousers](images/joggers.png "Jogging Trousers")

## Authentic Cuffed Jog Pants Mens

- Fleece Jogging Trousers
- Unisex Regular Fit
- Three End Combed Ringspun Fleece, Brushed Back
- Premium Jog Pants From The Russell Authentic Collection With A Super Soft Hand Feel & Modern Fit & Styling Details.
- Self-Fabric Welt Pockets With Concealed Zip Fastening
- Back Patch Pocket Flat, Chunky Drawcord With Button Hole Eyelets
- Rib At Cuff & Waistband
- S to 2XL
- 80% Cotton, 20% Polyester
- 280gsm

<button onclick="add2cart(event)" 
data-id="p4"
data-title="Fleece Jogging Trousers" 
data-price="90" 
data-col="black"
data-src="joggers.png">add</button>

