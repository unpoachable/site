# CAP 1

![Snap Back Flat Visor 6 Panel Cap](images/cap1.png "Snap Back Cap")

## Snap Back Flat Visor 6 Panel Cap


- Baseball Cap
- Unisex
- Twill
- 100% Polyester
- Six Panels
- 85 Degree Crown Angle
- High Shape Structured Profile
- Flat Visor
- PVC Snap Closure
- Tear Out, 2 Part Label
- One Size


<button onclick="add2cart(event)" 
data-id="p1"
data-title="cap1" 
data-price="40" 
data-col="black" 
data-src="cap1.png">add</button>